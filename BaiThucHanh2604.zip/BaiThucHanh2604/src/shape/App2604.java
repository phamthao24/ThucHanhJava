package shape;
import shape.Point;


public class App2604 {
    public static void main(String[] args) throws Exception {
        Point a=new Point();
        a.getTungDo();
        a.getHoanhDo();
        a.inDiem();
        a.nhapDiem();
    }
}
